<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../views/header.php';

// Query Agregat untuk Ringkasan Laporan
$totalProduct = $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
$totalInventoryValue = $pdo->query("SELECT SUM(stock * price) FROM products")->fetchColumn();
$lowStockCount = $pdo->query("SELECT COUNT(*) FROM products WHERE stock <= minimum_stock")->fetchColumn();

// Query Barang Keluar & Masuk
$totalIn = $pdo->query("SELECT SUM(quantity) FROM stock_movements WHERE type = 'IN'")->fetchColumn() ?: 0;
$totalOut = $pdo->query("SELECT SUM(quantity) FROM stock_movements WHERE type = 'OUT'")->fetchColumn() ?: 0;
?>

<h2>📊 Dashboard Laporan Stok</h2>

<div style="display: flex; gap: 20px; margin-bottom: 25px;">
    <div class="card" style="flex: 1; text-align: center; background-color: var(--soft-blue);">
        <h3>Total Produk</h3>
        <p style="font-size: 2em; margin: 0; font-weight: bold;"><?= $totalProduct ?></p>
    </div>
    <div class="card" style="flex: 1; text-align: center; background-color: #FEF3C7;">
        <h3>Stok Rendah</h3>
        <p style="font-size: 2em; margin: 0; font-weight: bold; color: #D97706;"><?= $lowStockCount ?></p>
    </div>
    <div class="card" style="flex: 1; text-align: center; background-color: #DCFCE7;">
        <h3>Nilai Total Aset</h3>
        <p style="font-size: 1.3em; margin: 10px 0; font-weight: bold;">Rp <?= number_format($totalInventoryValue ?: 0, 0, ',', '.') ?></p>
    </div>
</div>

<div class="card">
    <h3>📈 Pergerakan Stok Total</h3>
    <p>Total Sepatu Masuk (IN): <strong><?= $totalIn ?> pasang</strong></p>
    <p>Total Sepatu Keluar (OUT): <strong><?= $totalOut ?> pasang</strong></p>
</div>

<?php require_once __DIR__ . '/../views/footer.php'; ?>