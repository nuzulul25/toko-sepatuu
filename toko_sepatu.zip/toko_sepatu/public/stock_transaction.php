<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../views/header.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
    $type = $_POST['type'] ?? '';
    $quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);
    $notes = trim($_POST['notes'] ?? '');
    $user_id = $_SESSION['user']['id'];

    if (!$product_id || !$quantity || $quantity <= 0 || !in_array($type, ['IN', 'OUT'])) {
        $error = 'Input data transaksi tidak valid!';
    } else {
        try {
            // Mulai Transaksi Database
            $pdo->beginTransaction();

            // Lock row untuk mencegah race condition
            $stmt = $pdo->prepare("SELECT stock FROM products WHERE id = :id FOR UPDATE");
            $stmt->execute(['id' => $product_id]);
            $currentStock = $stmt->fetchColumn();

            if ($type === 'OUT' && $quantity > $currentStock) {
                throw new Exception("Stok tidak mencukupi! Stok saat ini: $currentStock");
            }

            // 1. Update Stok Produk
            $newStock = ($type === 'IN') ? $currentStock + $quantity : $currentStock - $quantity;
            $updateStmt = $pdo->prepare("UPDATE products SET stock = :stock WHERE id = :id");
            $updateStmt->execute(['stock' => $newStock, 'id' => $product_id]);

            // 2. Insert Histori Pergerakan Stok
            $logStmt = $pdo->prepare("INSERT INTO stock_movements (product_id, user_id, type, quantity, notes) VALUES (:product_id, :user_id, :type, :quantity, :notes)");
            $logStmt->execute([
                'product_id' => $product_id,
                'user_id'    => $user_id,
                'type'       => $type,
                'quantity'   => $quantity,
                'notes'      => $notes
            ]);

            // Commit jika semua berhasil
            $pdo->commit();
            $message = "Transaksi stok berhasil diperbarui!";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = $e->getMessage();
        }
    }
}

$products = $pdo->query("SELECT id, name, stock FROM products")->fetchAll();
?>

<h2>📦 Catat Transaksi Stok (Barang Masuk/Keluar)</h2>

<?php if ($message): ?><p style="color: green; font-weight: bold;"><?= e($message) ?></p><?php endif; ?>
<?php if ($error): ?><p style="color: red; font-weight: bold;"><?= e($error) ?></p><?php endif; ?>

<div class="card">
    <form method="POST">
        <div class="form-group">
            <label>Pilih Sepatu</label>
            <select name="product_id" required>
                <?php foreach ($products as $p): ?>
                    <option value="<?= $p['id'] ?>"><?= e($p['name']) ?> (Stok Sisa: <?= $p['stock'] ?>)</option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label>Jenis Transaksi</label>
            <select name="type" required>
                <option value="IN">Barang Masuk (IN)</option>
                <option value="OUT">Barang Keluar (OUT)</option>
            </select>
        </div>
        <div class="form-group">
            <label>Jumlah (Pasang)</label>
            <input type="number" name="quantity" min="1" required>
        </div>
        <div class="form-group">
            <label>Catatan / Keterangan</label>
            <input type="text" name="notes" placeholder="Misal: Pasokan baru / Restock toko">
        </div>
        <button type="submit" class="btn">Proses Transaksi</button>
    </form>
</div>

<?php require_once __DIR__ . '/../views/footer.php'; ?>