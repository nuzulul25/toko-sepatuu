<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/escape.php';

// Cek Login
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$search = trim($_GET['search'] ?? '');
$category_id = filter_input(INPUT_GET, 'category_id', FILTER_VALIDATE_INT);

$where = [];
$params = [];

if ($search !== '') {
    $where[] = '(p.name LIKE :search1 OR p.sku LIKE :search2)';
    $params['search1'] = "%$search%";
    $params['search2'] = "%$search%";
}

if ($category_id) {
    $where[] = 'p.category_id = :category_id';
    $params['category_id'] = $category_id;
}

$whereClause = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

// Fetch Products
$sql = "SELECT p.*, c.name AS category_name 
        FROM products p 
        JOIN categories c ON c.id = p.category_id 
        $whereClause 
        ORDER BY p.name ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$products = $stmt->fetchAll();

$categories = $pdo->query("SELECT * FROM categories")->fetchAll();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Sepatu - Toko Sepatu Inventory</title>
    <style>
        :root {
            --bg-cream: #FDFBF7;
            --card-cream: #F5EFE6;
            --primary-blue: #3B82F6;
            --soft-blue: #E0F2FE;
            --dark-blue: #1E3A8A;
            --text-dark: #1E293B;
        }
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background-color: var(--bg-cream); color: var(--text-dark); margin: 0; }
        header { background-color: var(--primary-blue); color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; }
        .nav-links a { color: white; margin-left: 20px; text-decoration: none; font-weight: 600; }
        .container { max-width: 1100px; margin: 30px auto; padding: 0 20px; }
        .card { background-color: white; border-radius: 8px; padding: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); border: 1px solid var(--card-cream); margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid var(--card-cream); }
        th { background-color: var(--soft-blue); color: var(--dark-blue); }
        .btn { background-color: var(--primary-blue); color: white; padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; font-size: 0.9em; }
        .btn:hover { opacity: 0.9; }
        .btn-success { background-color: #10B981; }
        .btn-warning { background-color: #F59E0B; }
        .btn-danger { background-color: #EF4444; }
        .badge-warning { background-color: #FEF08A; color: #854D0E; padding: 3px 8px; border-radius: 4px; font-size: 0.85em; }
    </style>
</head>
<body>
    <header>
        <h2>👟 Toko Sepatu Inventory</h2>
        <div class="nav-links">
            <a href="dashboard.php">Dashboard</a>
            <a href="products.php">Data Sepatu</a>
            <a href="stock_transaction.php">Transaksi Stok</a>
            <a href="logout.php">Logout (<?= e($_SESSION['user']['username']) ?>)</a>
        </div>
    </header>

    <div class="container">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2>Daftar Produk Sepatu</h2>
            <a href="product_add.php" class="btn btn-success">+ Tambah Produk</a>
        </div>

        <!-- Form Search & Filter -->
        <div class="card">
            <form method="GET" action="products.php" style="display: flex; gap: 10px; align-items: center;">
                <input type="text" name="search" placeholder="Cari SKU / Nama Sepatu..." value="<?= e($search) ?>" style="padding: 8px; flex: 1; border: 1px solid #CBD5E1; border-radius: 4px;">
                <select name="category_id" style="padding: 8px; border: 1px solid #CBD5E1; border-radius: 4px;">
                    <option value="">-- Semua Kategori --</option>
                    <?php foreach($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>" <?= ($category_id == $cat['id']) ? 'selected' : '' ?>>
                            <?= e($cat['name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn">Filter</button>
                <a href="products.php" class="btn" style="background: #64748B;">Reset</a>
            </form>
        </div>

        <!-- Tabel Produk -->
        <div class="card">
            <table>
                <thead>
                    <tr>
                        <th>SKU</th>
                        <th>Nama Sepatu</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($products) > 0): ?>
                        <?php foreach($products as $p): ?>
                        <tr>
                            <td><?= e($p['sku']) ?></td>
                            <td><strong><?= e($p['name']) ?></strong></td>
                            <td><?= e($p['category_name']) ?></td>
                            <td>Rp <?= number_format($p['price'], 0, ',', '.') ?></td>
                            <td><?= e($p['stock']) ?></td>
                            <td>
                                <?php if($p['stock'] <= 5): ?>
                                    <span class="badge-warning">Stok Rendah!</span>
                                <?php else: ?>
                                    <span style="color: green;">Aman</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="product_edit.php?id=<?= $p['id'] ?>" class="btn btn-warning" style="padding: 5px 10px;">Edit</a>
                                <a href="product_delete.php?id=<?= $p['id'] ?>" class="btn btn-danger" style="padding: 5px 10px;" onclick="return confirm('Yakin ingin menghapus produk ini?');">Hapus</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" style="text-align: center; color: #64748B;">Belum ada data produk sepatu.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>