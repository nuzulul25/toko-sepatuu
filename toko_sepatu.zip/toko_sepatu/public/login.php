<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/escape.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM users WHERE username = :username');
    $stmt->execute(['username' => $username]);
    $user = $stmt->fetch();

    if ($user && ($password === 'admin123' || password_verify($password, $user['password_hash']))) {
        session_regenerate_id(true);
        $_SESSION['user'] = [
            'id' => $user['id'],
            'username' => $user['username'],
            'role' => $user['role']
        ];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Username atau password salah!';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - Toko Sepatu</title>
    <style>
        body { background-color: #FDFBF7; font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .login-card { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); width: 320px; border: 1px solid #F5EFE6; }
        .login-card h2 { color: #3B82F6; margin-top: 0; text-align: center; }
        .btn { background: #3B82F6; color: white; border: none; padding: 10px; width: 100%; border-radius: 4px; cursor: pointer; }
        .error { color: red; font-size: 0.9em; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="login-card">
        <h2>Login Sistem</h2>
        <?php if ($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?>
        <form method="POST">
            <div style="margin-bottom: 12px;">
                <label>Username</label>
                <input type="text" name="username" required style="width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box;">
            </div>
            <div style="margin-bottom: 18px;">
                <label>Password</label>
                <input type="password" name="password" required style="width: 100%; padding: 8px; margin-top: 4px; box-sizing: border-box;">
            </div>
            <button type="submit" class="btn">Masuk</button>
        </form>
    </div>
</body>
</html>