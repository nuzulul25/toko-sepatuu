<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../helpers/escape.php';

if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}

$error = '';
$categories = $pdo->query("SELECT * FROM categories")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id = trim($_POST['category_id'] ?? '');
    $sku         = trim($_POST['sku'] ?? '');
    $name        = trim($_POST['name'] ?? '');
    $price       = trim($_POST['price'] ?? '');
    $stock       = trim($_POST['stock'] ?? '');

    if ($category_id === '' || $sku === '' || $name === '' || $price === '' || $stock === '') {
        $error = 'Semua kolom wajib diisi!';
    } else {
        $stmt = $pdo->prepare("INSERT INTO products (category_id, sku, name, price, stock) VALUES (:cat, :sku, :name, :price, :stock)");
        $stmt->execute([
            'cat'   => $category_id,
            'sku'   => $sku,
            'name'  => $name,
            'price' => $price,
            'stock' => $stock
        ]);
        header('Location: products.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Produk - Toko Sepatu</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, sans-serif; background-color: #FDFBF7; color: #1E293B; margin: 0; padding: 20px; }
        .card { max-width: 600px; margin: 40px auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); border: 1px solid #F5EFE6; }
        .form-group { margin-bottom: 15px; }
        label { display: block; font-weight: bold; margin-bottom: 5px; }
        input, select { width: 100%; padding: 8px; border: 1px solid #CBD5E1; border-radius: 4px; box-sizing: border-box; }
        .btn { background-color: #3B82F6; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; }
        .btn-secondary { background-color: #64748B; }
        .error { color: #EF4444; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="card">
        <h2>➕ Tambah Produk Sepatu Baru</h2>
        <?php if ($error): ?>
            <div class="error"><?= e($error) ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label>Kategori</label>
                <select name="category_id" required>
                    <option value="">-- Pilih Kategori --</option>
                    <?php foreach($categories as $cat): ?>
                        <option value="<?= $cat['id'] ?>"><?= e($cat['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>SKU Produk</label>
                <input type="text" name="sku" required placeholder="Contoh: SPT-RUN-008">
            </div>
            <div class="form-group">
                <label>Nama Sepatu</label>
                <input type="text" name="name" required placeholder="Contoh: Swift Glide Black">
            </div>
            <div class="form-group">
                <label>Harga (Rp)</label>
                <input type="number" name="price" required min="0" placeholder="450000">
            </div>
            <div class="form-group">
                <label>Stok Awal</label>
                <input type="number" name="stock" required min="0" value="10">
            </div>
            <button type="submit" class="btn">Simpan Produk</button>
            <a href="products.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</body>
</html>