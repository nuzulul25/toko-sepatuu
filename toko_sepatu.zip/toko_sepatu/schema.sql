CREATE DATABASE IF NOT EXISTS toko_sepatu;
USE toko_sepatu;

-- 1. Tabel Users
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'staff') NOT NULL DEFAULT 'staff',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Tabel Categories (Kategori Sepatu)
CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL
);

-- 3. Tabel Suppliers
CREATE TABLE suppliers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    phone VARCHAR(20)
);

-- 4. Tabel Products (Master Sepatu)
CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT NOT NULL,
    sku VARCHAR(50) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    price DECIMAL(12,2) NOT NULL CHECK (price >= 0),
    stock INT NOT NULL DEFAULT 0 CHECK (stock >= 0),
    minimum_stock INT NOT NULL DEFAULT 5,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT
);

-- 5. Tabel Many-to-Many: Product <-> Supplier
CREATE TABLE product_suppliers (
    product_id INT NOT NULL,
    supplier_id INT NOT NULL,
    supplier_price DECIMAL(12,2) CHECK (supplier_price >= 0),
    PRIMARY KEY (product_id, supplier_id),
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id) ON DELETE CASCADE
);

-- 6. Tabel Histori Transaksi Stok (In/Out)
CREATE TABLE stock_movements (
    id INT PRIMARY KEY AUTO_INCREMENT,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    type ENUM('IN', 'OUT') NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT
);

-- Seeding Default Data
INSERT INTO categories (id, name) VALUES (1, 'Running'), (2, 'Sneakers'), (3, 'Formal');
INSERT INTO suppliers (id, name, phone) VALUES (1, 'PT Sepatu Nusantara', '08123456789');

-- Password untuk admin & staff: "admin123"
INSERT INTO users (username, password_hash, role) VALUES 
('admin', '$2y$10$wN/sM0L50aI/wI14/Y/CMeTf3aH13M1S29W8Wz2oO9GzYhM9J/1Ge', 'admin'),
('staff', '$2y$10$wN/sM0L50aI/wI14/Y/CMeTf3aH13M1S29W8Wz2oO9GzYhM9J/1Ge', 'staff');

INSERT INTO products (category_id, sku, name, price, stock, minimum_stock) VALUES
(1, 'SPT-RUN-001', 'Aero Runner Blue', 450000.00, 15, 5),
(2, 'SPT-SNK-002', 'Casual Street Cream', 320000.00, 3, 5);