<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function checkLogin() {
    if (!isset($_SESSION['user'])) {
        header('Location: login.php');
        exit;
    }
}

function checkAdmin() {
    checkLogin();
    if ($_SESSION['user']['role'] !== 'admin') {
        http_response_code(403);
        echo "<h2 style='text-align:center; padding:50px;'>Akses Ditolak! Fitur ini khusus Admin.</h2>";
        exit;
    }
}