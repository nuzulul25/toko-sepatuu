<?php
require_once __DIR__ . '/../helpers/auth.php';
require_once __DIR__ . '/../helpers/escape.php';
checkLogin();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Toko Sepatu - Inventory System</title>
    <style>
        :root {
            --bg-cream: #FDFBF7;
            --card-cream: #F5EFE6;
            --primary-blue: #3B82F6;
            --soft-blue: #E0F2FE;
            --dark-blue: #1E3A8A;
            --text-dark: #1E293B;
            --accent-red: #EF4444;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: var(--bg-cream);
            color: var(--text-dark);
            margin: 0;
            padding: 0;
        }
        header {
            background-color: var(--primary-blue);
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);
        }
        nav a {
            color: white;
            text-decoration: none;
            margin-left: 15px;
            font-weight: 600;
        }
        nav a:hover { text-decoration: underline; }
        .container {
            max-width: 1100px;
            margin: 30px auto;
            padding: 0 20px;
        }
        .card {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
            border: 1px solid var(--card-cream);
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--card-cream);
        }
        th { background-color: var(--soft-blue); color: var(--dark-blue); }
        .btn {
            background-color: var(--primary-blue);
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }
        .btn-danger { background-color: var(--accent-red); }
        .btn:hover { opacity: 0.9; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: bold; }
        .form-group input, .form-group select {
            width: 100%; padding: 8px; box-sizing: border-box;
            border: 1px solid #CBD5E1; border-radius: 4px;
        }
        .badge-warning { background-color: #FEF08A; color: #854D0E; padding: 3px 8px; border-radius: 4px; font-size: 0.85em; }
    </style>
</head>
<body>
    <header>
        <h2>👟 Toko Sepatu Inventory</h2>
        <nav>
            <a href="dashboard.php">Dashboard</a>
            <a href="products.php">Data Sepatu</a>
            <a href="stock_transaction.php">Transaksi Stok</a>
            <a href="logout.php" style="color: #FECACA;">Logout (<?= e($_SESSION['user']['username']) ?>)</a>
        </nav>
    </header>
    <div class="container">